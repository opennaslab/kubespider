## kubespider source provider python sdk

#### 功能
 - 提供打包功能
 - 提供自动加入命令行参数功能